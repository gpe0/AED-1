#include "Tests/Interface.h"


using namespace std;

int main(int argc, char* argv[]) {

    cout << "AED 2021/2022 - Projeto 1" << endl;
    cout << endl << endl;

    Interface::menu(argc, argv);

    return 0;
}
